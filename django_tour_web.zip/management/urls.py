from django.conf.urls import url
from management import views

urlpatterns = [
    url(r'^$', views.index, name='homepage'),
    url(r'^signup/$', views.signup, name='signup'),
    url(r'^login/$', views.login, name='login'),
    url(r'^logout/$', views.logout, name='logout'),
    url(r'^set_password/$', views.set_password, name='set_password'),
    url(r'^add_attractions/$', views.add_attractions, name='add_attractions'),
    url(r'^add_hotel/$', views.add_hotel, name='add_hotel'),
    url(r'^add_route/$', views.add_route, name='add_route'),
    url(r'^message/$', views.message, name='message'),
]

from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import user_passes_test, login_required
from django.contrib.auth.models import User
from django.contrib import auth
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from management.models import MyUser, Attractions, Hotel, Route, Message
from django.core.urlresolvers import reverse
from management.utils import permission_check
import datetime

def index(request):
    user = request.user if request.user.is_authenticated() else None
    attractions_list = Attractions.objects.distinct()
    hotel_list = Hotel.objects.distinct()
    route_list = Route.objects.distinct()

    active_menu = ''
    page = request.GET.get('page')
    type = request.GET.get('type')
    if request.method == 'POST':
        keyword = request.POST.get('keyword', '')
        search_type = request.POST.get('search_type', '')
        if search_type == 'attractions':
            attractions_list = Attractions.objects.filter(name__contains=keyword)
            active_menu = 'menu_attractions'
        elif search_type == 'hotel':
            hotel_list = Hotel.objects.filter(name__contains=keyword)
            active_menu = 'menu_hotel'
        elif search_type == 'route':
            route_list = Route.objects.filter(name__contains=keyword)
            active_menu = 'menu_route'

    attractions_paginator = Paginator(attractions_list, 5)
    hotel_paginator = Paginator(hotel_list, 5)
    route_paginator = Paginator(route_list, 5)
    if type == 'attractions':
        try:
            attractions_list = attractions_paginator.page(page)
        except PageNotAnInteger:
            attractions_list = attractions_paginator.page(1)
        except EmptyPage:
            attractions_list = attractions_paginator.page(attractions_paginator.num_pages)
    elif type == 'hotel':
        try:
            attractions_list = hotel_paginator.page(page)
        except PageNotAnInteger:
            attractions_list = hotel_paginator.page(1)
        except EmptyPage:
            attractions_list = hotel_paginator.page(hotel_paginator.num_pages)
    elif type == 'route':
        try:
            attractions_list = route_paginator.page(page)
        except PageNotAnInteger:
            attractions_list = route_paginator.page(1)
        except EmptyPage:
            attractions_list = route_paginator.page(route_paginator.num_pages)
    content = {
        'user': user,
        'attractions_list': attractions_list,
        'hotel_list': hotel_list,
        'route_list': route_list,
        'active_menu': active_menu,
    }
    return render(request, 'management/index.html', content)


def signup(request):
    if request.user.is_authenticated():
        return HttpResponseRedirect(reverse('homepage'))
    state = None
    if request.method == 'POST':
        password = request.POST.get('password', '')
        repeat_password = request.POST.get('repeat_password', '')
        if password == '' or repeat_password == '':
            state = 'empty'
        elif password != repeat_password:
            state = 'repeat_error'
        else:
            username = request.POST.get('username', '')
            if User.objects.filter(username=username):
                state = 'user_exist'
            else:
                new_user = User.objects.create_user(username=username, password=password,
                                                    email=request.POST.get('email', ''))
                new_user.save()
                new_my_user = MyUser(user=new_user, nickname=request.POST.get('nickname', ''))
                new_my_user.save()
                state = 'success'
    content = {
        'state': state,
        'user': None,
    }
    return render(request, 'management/signup.html', content)


def login(request):
    if request.user.is_authenticated():
        return HttpResponseRedirect(reverse('homepage'))
    state = None
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return HttpResponseRedirect(reverse('homepage'))
        else:
            state = 'not_exist_or_password_error'
    content = {
        'state': state,
        'user': None
    }
    return render(request, 'management/login.html', content)


def logout(request):
    auth.logout(request)
    return HttpResponseRedirect(reverse('homepage'))


@login_required
def set_password(request):
    user = request.user
    state = None
    if request.method == 'POST':
        old_password = request.POST.get('old_password', '')
        new_password = request.POST.get('new_password', '')
        repeat_password = request.POST.get('repeat_password', '')
        if user.check_password(old_password):
            if not new_password:
                state = 'empty'
            elif new_password != repeat_password:
                state = 'repeat_error'
            else:
                user.set_password(new_password)
                user.save()
                state = 'success'
        else:
            state = 'password_error'
    content = {
        'user': user,
        'state': state,
    }
    return render(request, 'management/set_password.html', content)


def add_attractions(request):
    user = request.user
    state = None
    if request.method == 'POST':
        new_book = Attractions(
            name=request.POST.get('name', ''),
            image=request.POST.get('image', ''),
            sub_title=request.POST.get('sub_title', ''),
            description=request.POST.get('description', 0),
        )
        new_book.save()
        state = 'success'
    content = {
        'user': user,
        'state': state,
    }
    return render(request, 'management/add_attractions.html', content)


def add_hotel(request):
    user = request.user
    state = None
    if request.method == 'POST':
        new_hotel = Hotel(
            name=request.POST.get('name', ''),
            image=request.POST.get('image', ''),
            sub_title=request.POST.get('sub_title', ''),
            description=request.POST.get('description', 0),
        )
        new_hotel.save()
        state = 'success'
    content = {
        'user': user,
        'state': state,
    }
    return render(request, 'management/add_hotel.html', content)

def add_route(request):
    user = request.user
    state = None
    if request.method == 'POST':
        new_route = Route(
            name=request.POST.get('name', ''),
            image=request.POST.get('image', ''),
            sub_title=request.POST.get('sub_title', ''),
            description=request.POST.get('description', 0),
        )
        new_route.save()
        state = 'success'
    content = {
        'user': user,
        'state': state,
    }
    return render(request, 'management/add_route.html', content)

def message(request):
    user = request.user if request.user.is_authenticated() else None
    state = None
    message_list = Message.objects.all()

    print message_list
    if request.method == 'POST':
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        new_message = Message(
            title=request.POST.get('title', ''),
            content=request.POST.get('content', ''),
            add_user=user,
            add_time=now,
        )
        new_message.save()
        state = 'success'
        request.POST = {}
    content = {
        'user': user,
        'state': state,
        'message_list': message_list,
    }
    return render(request, 'management/message.html', content)